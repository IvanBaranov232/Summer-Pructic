# -*- coding: utf-8 -*-
"""
Tower Defense — летняя практика, расширенная версия (Python + Pygame).
Один файл, графика примитивами — внешние картинки не нужны.

Запуск:
    pip install pygame
    python main.py

Содержание (зеркало Unity-версии):
  * 9 уровней + 10-я кнопка-заглушка "Will be soon";
  * 5 волн на уровень, боссы на уровнях 3/6/9 (на 9-м — два);
  * АВТОЗАПУСК волн по таймеру + кнопка ПРИНУДИТЕЛЬНОГО запуска
    (бонус денег за каждую сэкономленную секунду);
  * 5 башен: Пушка, Мортира (сплэш), Лазер (луч с разогревом),
    Тесла (цепная молния), Мороз (аура замедления);
  * 7 врагов: раннер (иммунен к заморозке), солдат, танк (броня),
    лекарь (аура лечения), щитоносец (энергощит с регенерацией),
    делящийся (распадается на раннеров), босс;
  * типы урона: физический (режется бронёй) и энергетический
    (игнорирует броню, вдвое сильнее по щитам);
  * прокачка башен (3 уровня), продажа, 4 режима прицеливания;
  * меню уровней, сохранение прогресса и звёзд в td_save.json;
  * скорость игры x1/x2.

Управление:
    ЛКМ по кнопке башни внизу  — выбрать тип для постройки.
    ЛКМ по свободной клетке    — поставить башню.
    ЛКМ по своей башне         — открыть панель (улучшить/продать/цель).
    ПКМ или ESC                — отмена выбора / выход в меню (двойное ESC).
    Кнопка «Волна через Nс»    — принудительный запуск волны (бонус!).
    Пробел                     — пауза.  R — рестарт после конца уровня.

Секции файла повторяют деление проекта на 5 модулей (баннеры ниже),
чтобы реализация совпадала с планом практики.
"""

import json
import math
import os
import random
import sys

import pygame

# ============================================================================
# ОБЩИЕ КОНТРАКТЫ И КОНСТАНТЫ (аналог contracts.py / Contracts.cs)
# ============================================================================

CELL = 64
GRID_W, GRID_H = 16, 9
TOP_BAR = 48
BOTTOM_BAR = 132
WIDTH = GRID_W * CELL                       # 1024
FIELD_H = GRID_H * CELL                     # 576
HEIGHT = TOP_BAR + FIELD_H + BOTTOM_BAR     # 756

FPS = 60
SAVE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "td_save.json")

# Типы урона
PHYSICAL = "physical"   # броня врага: урон * (1 - armor)
ENERGY = "energy"       # игнорирует броню, x2 по энергощиту

# Режимы прицеливания
TARGET_MODES = ["first", "last", "strong", "close"]
TARGET_LABELS = {
    "first": "Цель: первый", "last": "Цель: последний",
    "strong": "Цель: сильнейший", "close": "Цель: ближайший",
}

# Цвета
C_BG = (24, 26, 32)
C_GRASS = (44, 78, 52)
C_GRASS2 = (40, 72, 48)
C_PATH = (148, 124, 86)
C_PANEL = (33, 36, 44)
C_TEXT = (228, 230, 236)
C_DIM = (150, 154, 164)
C_GOLD = (240, 200, 90)
C_HP = (220, 70, 70)
C_OK = (120, 220, 130)
C_BAD = (225, 90, 90)
C_SHIELD = (110, 180, 255)


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def cell_center(c):
    return (c[0] * CELL + CELL // 2, TOP_BAR + c[1] * CELL + CELL // 2)


# ============================================================================
# МОДУЛЬ C (Участник 3): КАРТА И ПУТИ
# Три раскладки пути; уровень N использует раскладку (N-1) % 3.
# Путь задан вэйпоинтами в клетках, клетки пути блокируются для постройки.
# ============================================================================

PATH_LAYOUTS = [
    [(0, 4), (3, 4), (3, 1), (7, 1), (7, 7), (11, 7), (11, 3), (15, 3)],
    [(0, 7), (4, 7), (4, 2), (8, 2), (8, 6), (12, 6), (12, 1), (15, 1)],
    [(0, 2), (2, 2), (2, 6), (6, 6), (6, 2), (10, 2), (10, 6), (13, 6), (13, 4), (15, 4)],
]


def expand_path_cells(waypoints):
    """Все клетки, по которым проходит путь (для запрета постройки)."""
    cells = set()
    for (x1, y1), (x2, y2) in zip(waypoints, waypoints[1:]):
        if x1 == x2:
            step = 1 if y2 > y1 else -1
            for y in range(y1, y2 + step, step):
                cells.add((x1, y))
        else:
            step = 1 if x2 > x1 else -1
            for x in range(x1, x2 + step, step):
                cells.add((x, y1))
    return cells


def path_pixels(waypoints):
    return [cell_center(w) for w in waypoints]


def path_length(pts):
    return sum(dist(a, b) for a, b in zip(pts, pts[1:]))


# ============================================================================
# МОДУЛЬ A (Участник 1): ВРАГИ — характеристики и поведение
# ============================================================================

ENEMY_SPECS = {
    # id: имя, hp, скорость(px/с), броня, награда, урон базе, способность, цвет
    "runner": dict(name="Раннер", hp=55, speed=150, armor=0.0, reward=8,
                   dmg=1, ability="slow_immune", color=(235, 210, 90), r=10),
    "soldier": dict(name="Солдат", hp=110, speed=90, armor=0.0, reward=12,
                    dmg=1, ability=None, color=(215, 90, 80), r=12),
    "tank": dict(name="Танк", hp=320, speed=55, armor=0.45, reward=25,
                 dmg=2, ability=None, color=(120, 125, 135), r=15),
    "healer": dict(name="Лекарь", hp=140, speed=85, armor=0.0, reward=20,
                   dmg=1, ability="heal_aura", color=(110, 220, 130), r=12,
                   aura_r=100, aura_power=8),
    "shielded": dict(name="Щитоносец", hp=160, speed=85, armor=0.10, reward=22,
                     dmg=1, ability="shield", color=(90, 150, 235), r=12,
                     shield_regen=6),          # % щита в секунду
    "splitter": dict(name="Делящийся", hp=180, speed=85, armor=0.0, reward=18,
                     dmg=1, ability="split", color=(190, 110, 220), r=13,
                     split_into="runner", split_count=2),
    "boss": dict(name="БОСС", hp=2500, speed=45, armor=0.30, reward=150,
                 dmg=10, ability="boss", color=(160, 40, 50), r=22),
}


class Enemy:
    def __init__(self, spec_id, hp_mul, reward_mul, path_pts, total_len):
        self.spec_id = spec_id
        self.spec = ENEMY_SPECS[spec_id]
        self.max_hp = self.spec["hp"] * hp_mul
        self.hp = self.max_hp
        ab = self.spec["ability"]
        self.max_shield = self.max_hp * 0.5 if ab == "shield" else 0.0
        self.shield = self.max_shield
        self.reward = int(round(self.spec["reward"] * reward_mul))

        self.path = path_pts
        self.total_len = total_len
        self.idx = 1                     # к какой точке идём
        self.pos = list(path_pts[0])
        self.travelled = 0.0

        self.slow_mul = 1.0
        self.slow_t = 0.0
        self.alive = True
        self.finished = False            # дошёл до базы

    # ------------------------------------------------------------------
    @property
    def progress(self):
        return min(1.0, self.travelled / self.total_len) if self.total_len else 0.0

    def update(self, dt, game):
        if not self.alive:
            return
        # замедление
        if self.slow_t > 0:
            self.slow_t -= dt
            if self.slow_t <= 0:
                self.slow_mul = 1.0
        # способности
        ab = self.spec["ability"]
        if ab == "heal_aura":
            for e in game.enemies:
                if e is not self and e.alive and dist(e.pos, self.pos) <= self.spec["aura_r"]:
                    e.heal(self.spec["aura_power"] * dt)
        elif ab == "shield" and self.shield < self.max_shield:
            self.shield = min(self.max_shield,
                              self.shield + self.max_shield * self.spec["shield_regen"] / 100.0 * dt)
        # движение
        step = self.spec["speed"] * self.slow_mul * dt
        while step > 0 and self.idx < len(self.path):
            tx, ty = self.path[self.idx]
            d = dist(self.pos, (tx, ty))
            if d <= step:
                self.pos = [tx, ty]
                self.travelled += d
                step -= d
                self.idx += 1
            else:
                k = step / d
                self.pos[0] += (tx - self.pos[0]) * k
                self.pos[1] += (ty - self.pos[1]) * k
                self.travelled += step
                step = 0
        if self.idx >= len(self.path):
            self.finished = True
            self.alive = False

    # ------------------------------------------------------------------
    def take_damage(self, amount, dtype):
        if not self.alive:
            return
        if dtype == PHYSICAL:
            amount *= 1.0 - self.spec["armor"]
        # энергощит принимает урон первым (энергия бьёт щит x2)
        if self.shield > 0:
            to_shield = amount * 2 if dtype == ENERGY else amount
            if to_shield <= self.shield:
                self.shield -= to_shield
                return
            amount -= self.shield / (2 if dtype == ENERGY else 1)
            self.shield = 0
        self.hp -= amount
        if self.hp <= 0:
            self.alive = False

    def apply_slow(self, mul, duration):
        ab = self.spec["ability"]
        if ab == "slow_immune":
            return
        if ab == "boss":                                  # босс: 40% эффекта
            mul = mul + (1.0 - mul) * 0.6
        if mul < self.slow_mul:
            self.slow_mul = mul
        self.slow_t = max(self.slow_t, duration)

    def heal(self, amount):
        if self.alive:
            self.hp = min(self.max_hp, self.hp + amount)


# ============================================================================
# МОДУЛЬ A (Участник 1): БАЗА УРОВНЕЙ — 9 уровней × 5 волн (data-driven)
# Формула как в Unity-версии: сквозная сложность power = (L-1)*5 + W,
# спец-враги подключаются по мере роста уровня, боссы на 3/6/9.
# ============================================================================

LEVEL_COUNT = 9          # 10-й — заглушка "Will be soon"
WAVES_PER_LEVEL = 5

LEVEL_TITLES = [
    "Тихая поляна", "Лесная тропа", "Брод через реку",
    "Старая крепость", "Выжженные земли", "Ледяной перевал",
    "Болота скверны", "Врата цитадели", "Последний рубеж",
]


def build_wave(level, wave):
    """Список групп: (enemy_id, count, interval, start_delay).

    Размер волны растёт умеренно (power = level + wave), а «толщина» врагов —
    через hp_mul уровня: экономика игрока на каждом уровне стартует с нуля,
    поэтому количество врагов не должно взрываться от номера уровня.
    """
    power = level + wave                                  # 2..14
    groups = [("soldier", 4 + power, max(0.45, 1.1 - power * 0.05), 0.0)]
    if wave >= 2 or level >= 2:
        groups.append(("runner", 2 + power // 2, 0.5, 2.5))
    if power >= 5:
        groups.append(("tank", power // 3, 1.6, 4.0))
    if level >= 2 and wave >= 2:
        groups.append(("healer", 1 + power // 6, 2.2, 3.0))
    if level >= 4 and wave >= 2:
        groups.append(("shielded", 1 + power // 6, 1.8, 5.0))
    if level >= 5 and wave >= 3:
        groups.append(("splitter", 1 + power // 8, 2.0, 6.0))
    if wave == WAVES_PER_LEVEL:                           # финал уровня
        groups.append(("soldier", 4 + level, 0.4, 8.0))
        groups.append(("runner", 3 + level, 0.35, 10.0))
        if level % 3 == 0:
            groups.append(("boss", 2 if level == 9 else 1, 6.0, 12.0))
    return groups


def get_level(n):
    n = max(1, min(LEVEL_COUNT, n))
    return dict(
        number=n,
        title=LEVEL_TITLES[n - 1],
        start_money=280 + (n - 1) * 100,
        start_lives=20,
        hp_mul=1.0 + (n - 1) * 0.20,
        reward_mul=1.0 + (n - 1) * 0.20,
        waves=[build_wave(n, w + 1) for w in range(WAVES_PER_LEVEL)],
        wave_bonus=[50 + n * 18 + (w + 1) * 10 for w in range(WAVES_PER_LEVEL)],
        layout=PATH_LAYOUTS[(n - 1) % len(PATH_LAYOUTS)],
    )


# ============================================================================
# МОДУЛЬ A (Участник 1): МЕНЕДЖЕР ВОЛН — автозапуск + принудительный запуск
# ============================================================================

AUTO_START_DELAY = 18.0     # секунд между волнами (автозапуск)
FIRST_WAVE_DELAY = 25.0     # перед первой волной — время на застройку
EARLY_BONUS_PER_SEC = 2.0   # монет за каждую сэкономленную секунду


class WaveManager:
    def __init__(self, game):
        self.game = game
        self.wave = 0                                   # 0 = не начато, 1..5
        self.total = WAVES_PER_LEVEL
        self.countdown = FIRST_WAVE_DELAY
        self.counting = True
        self.spawn_queue = []                           # [(t, enemy_id)], по времени
        self.wave_t = 0.0
        self.cleared_bonus_given = True

    def update(self, dt):
        g = self.game
        if g.state != "play":
            return
        if self.counting:
            self.countdown -= dt
            if self.countdown <= 0:
                self._begin_wave(early=False)           # АВТОЗАПУСК
            return
        # волна идёт: спавним по расписанию
        self.wave_t += dt
        while self.spawn_queue and self.spawn_queue[0][0] <= self.wave_t:
            _, eid = self.spawn_queue.pop(0)
            g.spawn_enemy(eid)
        # волна зачищена?
        if not self.spawn_queue and not any(e.alive for e in g.enemies):
            if not self.cleared_bonus_given:
                self.cleared_bonus_given = True
                g.money += g.level["wave_bonus"][self.wave - 1]
                if self.wave >= self.total:
                    g.win()
                else:
                    self.countdown = AUTO_START_DELAY
                    self.counting = True

    def force_start(self):
        """Кнопка «Начать волну» — ПРИНУДИТЕЛЬНЫЙ запуск с бонусом."""
        if self.counting and self.game.state == "play":
            if self.countdown > 1.0:
                self.game.money += int(self.countdown * EARLY_BONUS_PER_SEC)
            self._begin_wave(early=True)

    def _begin_wave(self, early):
        self.counting = False
        self.wave += 1
        self.wave_t = 0.0
        self.cleared_bonus_given = False
        self.spawn_queue = []
        for eid, count, interval, delay in self.game.level["waves"][self.wave - 1]:
            for i in range(count):
                self.spawn_queue.append((delay + i * interval, eid))
        self.spawn_queue.sort(key=lambda x: x[0])


# ============================================================================
# МОДУЛЬ B (Участник 2): БАШНИ И БОЙ — 5 типов, прокачка, снаряды
# ============================================================================

TOWER_SPECS = {
    "cannon": dict(
        name="Пушка", kind="cannon", dtype=PHYSICAL, cost=100,
        color=(180, 185, 195), desc="Одиночные снаряды. Броня врага режет урон.",
        levels=[dict(dmg=26, rng=170, rate=1.2, ucost=0),
                dict(dmg=38, rng=185, rate=1.5, ucost=70),
                dict(dmg=56, rng=200, rate=1.9, ucost=120)]),
    "mortar": dict(
        name="Мортира", kind="mortar", dtype=PHYSICAL, cost=160,
        color=(190, 150, 100), desc="Сплэш-урон по площади, медленная.",
        levels=[dict(dmg=38, rng=200, rate=0.5, splash=70, ucost=0),
                dict(dmg=55, rng=215, rate=0.6, splash=80, ucost=110),
                dict(dmg=80, rng=230, rate=0.7, splash=95, ucost=190)]),
    "laser": dict(
        name="Лазер", kind="laser", dtype=ENERGY, cost=180,
        color=(235, 90, 90), desc="Луч: урон растёт, пока держит одну цель. Игнорирует броню.",
        levels=[dict(dmg=22, rng=160, rate=0, ramp_max=2.5, ramp_t=3.0, ucost=0),
                dict(dmg=32, rng=175, rate=0, ramp_max=2.5, ramp_t=2.6, ucost=125),
                dict(dmg=46, rng=190, rate=0, ramp_max=3.0, ramp_t=2.2, ucost=215)]),
    "tesla": dict(
        name="Тесла", kind="tesla", dtype=ENERGY, cost=200,
        color=(120, 190, 255), desc="Цепная молния по нескольким целям. Игнорирует броню.",
        levels=[dict(dmg=30, rng=150, rate=0.8, chain=3, falloff=0.7, jump=110, ucost=0),
                dict(dmg=44, rng=165, rate=0.9, chain=4, falloff=0.7, jump=120, ucost=140),
                dict(dmg=62, rng=180, rate=1.0, chain=5, falloff=0.75, jump=130, ucost=240)]),
    "frost": dict(
        name="Мороз", kind="frost", dtype=None, cost=120,
        color=(140, 225, 235), desc="Не бьёт: периодически замедляет всех в радиусе.",
        levels=[dict(dmg=0, rng=130, rate=1.0, slow=0.55, slow_t=1.2, ucost=0),
                dict(dmg=0, rng=145, rate=1.0, slow=0.45, slow_t=1.5, ucost=85),
                dict(dmg=0, rng=165, rate=1.0, slow=0.35, slow_t=1.8, ucost=145)]),
}
SHOP_ORDER = ["cannon", "mortar", "laser", "tesla", "frost"]


class Projectile:
    __slots__ = ("pos", "target", "last", "dmg", "dtype", "splash", "speed", "done")

    def __init__(self, pos, target, dmg, dtype, splash):
        self.pos = list(pos)
        self.target = target
        self.last = list(target.pos)
        self.dmg = dmg
        self.dtype = dtype
        self.splash = splash
        self.speed = 420.0
        self.done = False

    def update(self, dt, game):
        if self.target.alive:
            self.last = list(self.target.pos)
        d = dist(self.pos, self.last)
        step = self.speed * dt
        if d <= step:
            self._hit(game)
            return
        k = step / d
        self.pos[0] += (self.last[0] - self.pos[0]) * k
        self.pos[1] += (self.last[1] - self.pos[1]) * k

    def _hit(self, game):
        self.done = True
        if self.splash > 0:
            for e in game.enemies:
                if not e.alive:
                    continue
                d = dist(e.pos, self.last)
                if d <= self.splash:
                    falloff = 1.0 - 0.5 * (d / self.splash)
                    e.take_damage(self.dmg * falloff, self.dtype)
            game.effects.append(dict(kind="boom", pos=tuple(self.last),
                                     r=self.splash, t=0.25, t0=0.25))
        elif self.target.alive:
            self.target.take_damage(self.dmg, self.dtype)
            game.effects.append(dict(kind="hit", pos=tuple(self.last), t=0.12, t0=0.12))


class Tower:
    def __init__(self, cell, spec_id):
        self.cell = cell
        self.pos = cell_center(cell)
        self.spec_id = spec_id
        self.spec = TOWER_SPECS[spec_id]
        self.level = 0
        self.mode = 0                       # индекс TARGET_MODES
        self.cooldown = 0.0
        self.target = None
        self.ramp_t = 0.0                   # лазер: разогрев
        self.invested = self.spec["cost"]

    # ------------------------------------------------------------------
    @property
    def st(self):
        return self.spec["levels"][self.level]

    @property
    def can_upgrade(self):
        return self.level < len(self.spec["levels"]) - 1

    @property
    def upgrade_cost(self):
        return self.spec["levels"][self.level + 1]["ucost"] if self.can_upgrade else 0

    @property
    def sell_price(self):
        return int(self.invested * 0.7)

    def upgrade(self, game):
        if self.can_upgrade and game.money >= self.upgrade_cost:
            game.money -= self.upgrade_cost
            self.invested += self.upgrade_cost
            self.level += 1

    # ------------------------------------------------------------------
    def acquire(self, game):
        rng = self.st["rng"]
        if (self.target is not None and self.target.alive
                and dist(self.target.pos, self.pos) <= rng):
            return
        best, best_score = None, -1e18
        mode = TARGET_MODES[self.mode]
        for e in game.enemies:
            if not e.alive:
                continue
            d = dist(e.pos, self.pos)
            if d > rng:
                continue
            score = (e.progress if mode == "first" else
                     -e.progress if mode == "last" else
                     e.max_hp if mode == "strong" else
                     -d)
            if score > best_score:
                best, best_score = e, score
        if self.target is not best and self.spec["kind"] == "laser":
            self.ramp_t = 0.0               # смена цели сбрасывает разогрев
        self.target = best

    def update(self, dt, game):
        kind = self.spec["kind"]
        self.cooldown -= dt

        if kind == "frost":                 # цели не нужны — пульс по площади
            if self.cooldown <= 0:
                self.cooldown = 1.0 / self.st["rate"]
                hit = False
                for e in game.enemies:
                    if e.alive and dist(e.pos, self.pos) <= self.st["rng"]:
                        e.apply_slow(self.st["slow"], self.st["slow_t"])
                        hit = True
                if hit:
                    game.effects.append(dict(kind="pulse", pos=self.pos,
                                             r=self.st["rng"], t=0.4, t0=0.4))
            return

        self.acquire(game)
        if self.target is None:
            self.ramp_t = 0.0
            return

        if kind == "laser":                 # непрерывный луч, dmg = DPS
            self.ramp_t += dt
            ramp = 1.0 + (self.st["ramp_max"] - 1.0) * min(1.0, self.ramp_t / self.st["ramp_t"])
            self.target.take_damage(self.st["dmg"] * ramp * dt, ENERGY)
            return

        if self.cooldown > 0:
            return
        self.cooldown = 1.0 / self.st["rate"]

        if kind == "tesla":                 # цепная молния
            chain = [self.target]
            cur, dmg = self.target, self.st["dmg"]
            for _ in range(self.st["chain"] - 1):
                nxt, best = None, self.st["jump"]
                for e in game.enemies:
                    if not e.alive or e in chain:
                        continue
                    d = dist(e.pos, cur.pos)
                    if d < best:
                        best, nxt = d, e
                if nxt is None:
                    break
                chain.append(nxt)
                cur = nxt
            pts = [self.pos]
            for e in chain:
                e.take_damage(dmg, ENERGY)
                dmg *= self.st["falloff"]
                pts.append(tuple(e.pos))
            game.effects.append(dict(kind="arc", pts=pts, t=0.12, t0=0.12))
        else:                               # cannon / mortar — снаряд
            game.projectiles.append(Projectile(
                self.pos, self.target, self.st["dmg"], self.spec["dtype"],
                self.st.get("splash", 0)))


# ============================================================================
# МОДУЛЬ E (Участник 5): СОХРАНЕНИЯ — прогресс и звёзды (td_save.json)
# ============================================================================

def load_save():
    try:
        with open(SAVE_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        data.setdefault("unlocked", 1)
        data.setdefault("best_lives", {})
        return data
    except Exception:
        return {"unlocked": 1, "best_lives": {}}


def write_save(data):
    try:
        with open(SAVE_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def stars_for(lives):
    if lives >= 18:
        return 3
    if lives >= 10:
        return 2
    if lives >= 1:
        return 1
    return 0


# ============================================================================
# МОДУЛЬ E (Участник 5): ИГРОВАЯ СЦЕНА — состояние уровня и оркестрация
# ============================================================================

class Game:
    def __init__(self, level_no, save):
        self.save = save
        self.level = get_level(level_no)
        self.waypoints = self.level["layout"]
        self.path_pts = path_pixels(self.waypoints)
        self.total_len = path_length(self.path_pts)
        self.blocked = expand_path_cells(self.waypoints)

        self.money = self.level["start_money"]
        self.lives = self.level["start_lives"]
        self.speed = 1.0
        self.paused = False
        self.state = "play"                  # play / win / lose

        self.enemies = []
        self.towers = {}                     # cell -> Tower
        self.projectiles = []
        self.effects = []

        self.waves = WaveManager(self)
        self.build_sel = None                # выбранный тип для постройки
        self.tower_sel = None                # выбранная построенная башня
        self.ui_rects = {}                   # прямоугольники кнопок (заполняет draw)

    # ------------------------------------------------------------------
    def spawn_enemy(self, eid):
        self.enemies.append(Enemy(eid, self.level["hp_mul"],
                                  self.level["reward_mul"],
                                  self.path_pts, self.total_len))

    def win(self):
        self.state = "win"
        lvl = str(self.level["number"])
        self.save["unlocked"] = max(self.save["unlocked"],
                                    min(LEVEL_COUNT, self.level["number"] + 1))
        self.save["best_lives"][lvl] = max(self.save["best_lives"].get(lvl, 0), self.lives)
        write_save(self.save)

    def lose(self):
        self.state = "lose"

    # ------------------------------------------------------------------
    def update(self, raw_dt):
        if self.state != "play" or self.paused:
            return
        dt = raw_dt * self.speed

        self.waves.update(dt)

        for e in self.enemies:
            e.update(dt, self)
        for t in self.towers.values():
            t.update(dt, self)
        for p in self.projectiles:
            p.update(dt, self)

        # уборка: награды, делящиеся, прорывы к базе
        survivors = []
        for e in self.enemies:
            if e.alive:
                survivors.append(e)
                continue
            if e.finished:
                self.lives -= e.spec["dmg"]
            else:
                self.money += e.reward
                if e.spec["ability"] == "split":
                    for _ in range(e.spec["split_count"]):
                        child = Enemy(e.spec["split_into"], self.level["hp_mul"],
                                      self.level["reward_mul"], self.path_pts, self.total_len)
                        child.pos = [e.pos[0] + random.uniform(-12, 12),
                                     e.pos[1] + random.uniform(-12, 12)]
                        child.idx = e.idx
                        child.travelled = e.travelled
                        survivors.append(child)
        self.enemies = survivors
        self.projectiles = [p for p in self.projectiles if not p.done]

        for fx in self.effects:
            fx["t"] -= dt
        self.effects = [fx for fx in self.effects if fx["t"] > 0]

        if self.lives <= 0:
            self.lives = 0
            self.lose()

    # ------------------------------------------------------------------
    # МОДУЛЬ D (Участник 4): обработка ввода игровой сцены
    # ------------------------------------------------------------------
    def handle_click(self, mpos, button):
        if button == 3:                                     # ПКМ — отмена
            self.build_sel = None
            self.tower_sel = None
            return None
        if button != 1:
            return None

        # конец уровня: кнопки оверлея
        if self.state in ("win", "lose"):
            for key in ("btn_restart", "btn_menu", "btn_next"):
                r = self.ui_rects.get(key)
                if r and r.collidepoint(mpos):
                    return key
            return None

        # кнопки нижней панели
        for key, r in self.ui_rects.items():
            if not r.collidepoint(mpos):
                continue
            if key.startswith("shop_"):
                sid = key[5:]
                self.build_sel = None if self.build_sel == sid else sid
                self.tower_sel = None
                return None
            if key == "start_wave":
                self.waves.force_start()
                return None
            if key == "speed1":
                self.speed = 1.0
                return None
            if key == "speed2":
                self.speed = 2.0
                return None
            if key == "t_upgrade" and self.tower_sel:
                self.tower_sel.upgrade(self)
                return None
            if key == "t_sell" and self.tower_sel:
                self.money += self.tower_sel.sell_price
                del self.towers[self.tower_sel.cell]
                self.tower_sel = None
                return None
            if key == "t_mode" and self.tower_sel:
                self.tower_sel.mode = (self.tower_sel.mode + 1) % len(TARGET_MODES)
                return None

        # клик по полю
        if TOP_BAR <= mpos[1] < TOP_BAR + FIELD_H:
            cell = (mpos[0] // CELL, (mpos[1] - TOP_BAR) // CELL)
            if cell in self.towers:
                self.tower_sel = self.towers[cell]
                self.build_sel = None
            elif (self.build_sel and cell not in self.blocked
                  and 0 <= cell[0] < GRID_W and 0 <= cell[1] < GRID_H):
                spec = TOWER_SPECS[self.build_sel]
                if self.money >= spec["cost"]:
                    self.money -= spec["cost"]
                    self.towers[cell] = Tower(cell, self.build_sel)
            else:
                self.tower_sel = None
        return None


# ============================================================================
# МОДУЛЬ D (Участник 4): ОТРИСОВКА — поле, враги, башни, HUD, меню
# ============================================================================

class Renderer:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont("arial", 17)
        self.font_s = pygame.font.SysFont("arial", 14)
        self.font_b = pygame.font.SysFont("arial", 40, bold=True)
        self.font_m = pygame.font.SysFont("arial", 24, bold=True)

    def text(self, s, pos, color=C_TEXT, font=None, center=False):
        surf = (font or self.font).render(s, True, color)
        r = surf.get_rect()
        if center:
            r.center = pos
        else:
            r.topleft = pos
        self.screen.blit(surf, r)
        return r

    # ------------------------------------------------------------------
    def draw_game(self, g):
        scr = self.screen
        scr.fill(C_BG)

        # поле: трава в шахматку + путь
        for cy in range(GRID_H):
            for cx in range(GRID_W):
                col = C_GRASS if (cx + cy) % 2 == 0 else C_GRASS2
                if (cx, cy) in g.blocked:
                    col = C_PATH
                pygame.draw.rect(scr, col, (cx * CELL, TOP_BAR + cy * CELL, CELL, CELL))
        # старт/база
        pygame.draw.circle(scr, (90, 200, 110), cell_center(g.waypoints[0]), 14)
        pygame.draw.circle(scr, (210, 90, 90), cell_center(g.waypoints[-1]), 14)

        # подсветка клетки при постройке
        if g.build_sel:
            mx, my = pygame.mouse.get_pos()
            if TOP_BAR <= my < TOP_BAR + FIELD_H:
                cell = (mx // CELL, (my - TOP_BAR) // CELL)
                ok = cell not in g.blocked and cell not in g.towers
                col = (90, 220, 110) if ok else (220, 90, 90)
                pygame.draw.rect(scr, col,
                                 (cell[0] * CELL, TOP_BAR + cell[1] * CELL, CELL, CELL), 3)
                pygame.draw.circle(scr, col, cell_center(cell),
                                   TOWER_SPECS[g.build_sel]["levels"][0]["rng"], 1)

        # башни
        for t in g.towers.values():
            self.draw_tower(t, g)

        # радиус выбранной башни
        if g.tower_sel:
            pygame.draw.circle(scr, (140, 230, 240), g.tower_sel.pos,
                               int(g.tower_sel.st["rng"]), 1)

        # враги
        for e in g.enemies:
            self.draw_enemy(e)

        # снаряды
        for p in g.projectiles:
            pygame.draw.circle(scr, (250, 240, 180), (int(p.pos[0]), int(p.pos[1])), 4)

        # эффекты
        for fx in g.effects:
            k = fx["t"] / fx["t0"]
            if fx["kind"] == "boom":
                pygame.draw.circle(scr, (250, 170, 80), fx["pos"],
                                   int(fx["r"] * (1 - k) + 8), 2)
            elif fx["kind"] == "hit":
                pygame.draw.circle(scr, (255, 255, 200), fx["pos"], int(6 * k + 2), 1)
            elif fx["kind"] == "pulse":
                pygame.draw.circle(scr, C_SHIELD, fx["pos"], int(fx["r"] * (1 - k)), 1)
            elif fx["kind"] == "arc":
                pts = fx["pts"]
                for a, b in zip(pts, pts[1:]):
                    mid = ((a[0] + b[0]) / 2 + random.uniform(-6, 6),
                           (a[1] + b[1]) / 2 + random.uniform(-6, 6))
                    pygame.draw.lines(scr, (160, 215, 255), False, [a, mid, b], 2)

        # лазерные лучи (поверх врагов)
        for t in g.towers.values():
            if t.spec["kind"] == "laser" and t.target is not None and t.target.alive:
                ramp = min(1.0, t.ramp_t / t.st["ramp_t"])
                w = 2 + int(3 * ramp)
                pygame.draw.line(scr, (255, 80 + int(100 * ramp), 80),
                                 t.pos, (int(t.target.pos[0]), int(t.target.pos[1])), w)

        self.draw_hud(g)

        if g.state in ("win", "lose"):
            self.draw_end(g)
        elif g.paused:
            self.text("ПАУЗА (пробел)", (WIDTH // 2, TOP_BAR + FIELD_H // 2),
                      C_GOLD, self.font_b, center=True)

    # ------------------------------------------------------------------
    def draw_enemy(self, e):
        scr = self.screen
        x, y = int(e.pos[0]), int(e.pos[1])
        r = e.spec["r"]
        sid = e.spec_id
        col = e.spec["color"]
        if sid == "tank":
            pygame.draw.rect(scr, col, (x - r, y - r, r * 2, r * 2))
            pygame.draw.rect(scr, (60, 62, 70), (x - r, y - r, r * 2, r * 2), 2)
        elif sid == "runner":
            pygame.draw.polygon(scr, col, [(x, y - r), (x - r, y + r), (x + r, y + r)])
        elif sid == "boss":
            pts = [(x + r * math.cos(a), y + r * math.sin(a))
                   for a in [math.pi / 6 + i * math.pi / 3 for i in range(6)]]
            pygame.draw.polygon(scr, col, pts)
            pygame.draw.polygon(scr, (40, 10, 12), pts, 3)
        else:
            pygame.draw.circle(scr, col, (x, y), r)
        if sid == "healer":
            pygame.draw.line(scr, (250, 250, 250), (x - 5, y), (x + 5, y), 2)
            pygame.draw.line(scr, (250, 250, 250), (x, y - 5), (x, y + 5), 2)
        if e.shield > 0:
            pygame.draw.circle(scr, C_SHIELD, (x, y), r + 4, 2)
        if e.slow_mul < 1.0:
            pygame.draw.circle(scr, (160, 230, 240), (x, y), r + 1, 1)
        # полоска HP (+щит)
        w = max(24, r * 2)
        pygame.draw.rect(scr, (20, 20, 24), (x - w // 2, y - r - 10, w, 4))
        pygame.draw.rect(scr, C_HP, (x - w // 2, y - r - 10, int(w * e.hp / e.max_hp), 4))
        if e.max_shield > 0:
            pygame.draw.rect(scr, C_SHIELD,
                             (x - w // 2, y - r - 15, int(w * e.shield / e.max_shield), 3))

    def draw_tower(self, t, g):
        scr = self.screen
        x, y = t.pos
        base = 22 + t.level * 3
        pygame.draw.rect(scr, (58, 62, 72), (x - base // 2, y - base // 2, base, base),
                         border_radius=4)
        col = t.spec["color"]
        kind = t.spec["kind"]
        if kind == "laser":
            pygame.draw.polygon(scr, col, [(x, y - 12), (x + 12, y), (x, y + 12), (x - 12, y)])
        elif kind == "frost":
            pygame.draw.circle(scr, col, (x, y), 11)
            pygame.draw.circle(scr, (250, 250, 255), (x, y), 5)
        elif kind == "tesla":
            pygame.draw.circle(scr, col, (x, y), 11)
            pygame.draw.line(scr, (250, 250, 255), (x - 4, y - 6), (x + 1, y), 2)
            pygame.draw.line(scr, (250, 250, 255), (x + 1, y), (x - 1, y + 6), 2)
        else:
            pygame.draw.circle(scr, col, (x, y), 11)
            if t.target is not None and t.target.alive:
                tx, ty = t.target.pos
                d = dist((x, y), (tx, ty)) or 1
                pygame.draw.line(scr, (235, 238, 245), (x, y),
                                 (x + (tx - x) / d * 16, y + (ty - y) / d * 16), 4)
        # пипсы уровня
        for i in range(t.level):
            pygame.draw.circle(scr, C_GOLD, (x - 8 + i * 8, y + base // 2 + 6), 3)

    # ------------------------------------------------------------------
    def draw_hud(self, g):
        scr = self.screen
        ui = g.ui_rects
        ui.clear()

        # верхняя панель
        pygame.draw.rect(scr, C_PANEL, (0, 0, WIDTH, TOP_BAR))
        self.text(f"$ {g.money}", (14, 13), C_GOLD)
        self.text(f"Жизни: {g.lives}", (130, 13),
                  C_OK if g.lives > 9 else C_BAD)
        self.text(f"Волна {max(1, g.waves.wave)}/{g.waves.total}", (260, 13))
        self.text(f"Уровень {g.level['number']}: {g.level['title']}", (400, 13), C_DIM)
        self.text(f"x{int(g.speed)}", (WIDTH - 36, 13), C_DIM)

        # нижняя панель
        py = TOP_BAR + FIELD_H
        pygame.draw.rect(scr, C_PANEL, (0, py, WIDTH, BOTTOM_BAR))

        # магазин
        bx = 10
        for sid in SHOP_ORDER:
            spec = TOWER_SPECS[sid]
            r = pygame.Rect(bx, py + 10, 132, 52)
            sel = g.build_sel == sid
            can = g.money >= spec["cost"]
            pygame.draw.rect(scr, (70, 110, 80) if sel else (48, 52, 62), r, border_radius=6)
            pygame.draw.rect(scr, spec["color"] if can else (90, 90, 95), r, 2, border_radius=6)
            self.text(spec["name"], (r.x + 8, r.y + 6),
                      C_TEXT if can else C_DIM)
            self.text(f"${spec['cost']}", (r.x + 8, r.y + 27),
                      C_GOLD if can else C_DIM, self.font_s)
            ui[f"shop_{sid}"] = r
            bx += 140

        # кнопка запуска волны (принудительный запуск)
        r = pygame.Rect(WIDTH - 230, py + 10, 220, 52)
        if g.waves.counting:
            pygame.draw.rect(scr, (60, 110, 70), r, border_radius=8)
            self.text(f"Волна через {math.ceil(g.waves.countdown)}с",
                      (r.centerx, r.centery - 11), C_TEXT, self.font_s, center=True)
            self.text("НАЧАТЬ СЕЙЧАС (+бонус)", (r.centerx, r.centery + 9),
                      C_GOLD, self.font_s, center=True)
        else:
            pygame.draw.rect(scr, (48, 52, 62), r, border_radius=8)
            self.text("Волна идёт...", r.center, C_DIM, self.font_s, center=True)
        ui["start_wave"] = r

        # скорость
        r1 = pygame.Rect(WIDTH - 230, py + 70, 105, 28)
        r2 = pygame.Rect(WIDTH - 119, py + 70, 105, 28)
        for r, lab, key, val in ((r1, "x1", "speed1", 1.0), (r2, "x2", "speed2", 2.0)):
            on = abs(g.speed - val) < 0.01
            pygame.draw.rect(scr, (70, 110, 80) if on else (48, 52, 62), r, border_radius=6)
            self.text(lab, r.center, C_TEXT, self.font_s, center=True)
            ui[key] = r

        # панель выбранной башни
        if g.tower_sel:
            t = g.tower_sel
            self.text(f"{t.spec['name']} (ур. {t.level + 1})  "
                      f"урон {t.st['dmg']}  радиус {t.st['rng']}",
                      (10, py + 72), C_TEXT, self.font_s)
            bx = 10
            if t.can_upgrade:
                r = pygame.Rect(bx, py + 94, 170, 28)
                can = g.money >= t.upgrade_cost
                pygame.draw.rect(scr, (60, 110, 70) if can else (48, 52, 62), r,
                                 border_radius=6)
                self.text(f"Улучшить (${t.upgrade_cost})", r.center,
                          C_TEXT if can else C_DIM, self.font_s, center=True)
                ui["t_upgrade"] = r
                bx += 178
            r = pygame.Rect(bx, py + 94, 150, 28)
            pygame.draw.rect(scr, (110, 70, 60), r, border_radius=6)
            self.text(f"Продать (+${t.sell_price})", r.center, C_TEXT,
                      self.font_s, center=True)
            ui["t_sell"] = r
            bx += 158
            r = pygame.Rect(bx, py + 94, 170, 28)
            pygame.draw.rect(scr, (48, 52, 62), r, border_radius=6)
            self.text(TARGET_LABELS[TARGET_MODES[t.mode]], r.center, C_TEXT,
                      self.font_s, center=True)
            ui["t_mode"] = r
        elif g.build_sel:
            self.text(TOWER_SPECS[g.build_sel]["desc"], (10, py + 76), C_DIM, self.font_s)
            self.text("ЛКМ по свободной клетке — построить, ПКМ — отмена",
                      (10, py + 98), C_DIM, self.font_s)

    # ------------------------------------------------------------------
    def draw_end(self, g):
        scr = self.screen
        veil = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        veil.fill((10, 10, 14, 190))
        scr.blit(veil, (0, 0))
        cy = HEIGHT // 2
        if g.state == "win":
            self.text("ПОБЕДА!", (WIDTH // 2, cy - 90), C_OK, self.font_b, center=True)
            s = stars_for(g.lives)
            self.text(f"Звёзды: {s}/3   (осталось жизней: {g.lives})",
                      (WIDTH // 2, cy - 40), C_GOLD, self.font_m, center=True)
        else:
            self.text("ПОРАЖЕНИЕ", (WIDTH // 2, cy - 90), C_BAD, self.font_b, center=True)

        bw, bh = 240, 46
        r = pygame.Rect(WIDTH // 2 - bw - 130, cy + 10, bw, bh)
        pygame.draw.rect(scr, (60, 90, 120), r, border_radius=8)
        self.text("Заново (R)", r.center, C_TEXT, self.font_m, center=True)
        g.ui_rects["btn_restart"] = r

        r = pygame.Rect(WIDTH // 2 - bw // 2, cy + 10, bw, bh)
        pygame.draw.rect(scr, (70, 70, 90), r, border_radius=8)
        self.text("В меню", r.center, C_TEXT, self.font_m, center=True)
        g.ui_rects["btn_menu"] = r

        if g.state == "win" and g.level["number"] < LEVEL_COUNT:
            r = pygame.Rect(WIDTH // 2 + 130, cy + 10, bw, bh)
            pygame.draw.rect(scr, (60, 120, 80), r, border_radius=8)
            self.text("Следующий ->", r.center, C_TEXT, self.font_m, center=True)
            g.ui_rects["btn_next"] = r

    # ------------------------------------------------------------------
    # Меню выбора уровней: 9 уровней + 10-я заглушка "Will be soon"
    # ------------------------------------------------------------------
    def draw_menu(self, save, rects):
        scr = self.screen
        scr.fill(C_BG)
        rects.clear()
        self.text("TOWER DEFENSE", (WIDTH // 2, 70), C_GOLD, self.font_b, center=True)
        self.text("Летняя практика — выбор уровня", (WIDTH // 2, 120),
                  C_DIM, self.font_m, center=True)

        bw, bh, gap = 170, 110, 18
        cols = 5
        x0 = (WIDTH - cols * bw - (cols - 1) * gap) // 2
        y0 = 190
        for i in range(10):
            col, row = i % cols, i // cols
            r = pygame.Rect(x0 + col * (bw + gap), y0 + row * (bh + gap), bw, bh)
            n = i + 1
            if n > LEVEL_COUNT:                          # ---- заглушка ----
                pygame.draw.rect(scr, (40, 42, 50), r, border_radius=10)
                pygame.draw.rect(scr, (70, 72, 82), r, 2, border_radius=10)
                self.text("Will be", (r.centerx, r.centery - 14), C_DIM,
                          self.font_m, center=True)
                self.text("soon", (r.centerx, r.centery + 14), C_DIM,
                          self.font_m, center=True)
                continue
            unlocked = n <= save["unlocked"]
            stars = stars_for(save["best_lives"].get(str(n), 0))
            pygame.draw.rect(scr, (52, 68, 58) if unlocked else (40, 42, 50),
                             r, border_radius=10)
            pygame.draw.rect(scr, C_OK if unlocked else (70, 72, 82), r, 2,
                             border_radius=10)
            self.text(str(n), (r.centerx, r.centery - 22),
                      C_TEXT if unlocked else C_DIM, self.font_b, center=True)
            if unlocked:
                self.text(LEVEL_TITLES[n - 1], (r.centerx, r.centery + 16),
                          C_DIM, self.font_s, center=True)
                self.text(f"{stars}/3 *" if stars else "—",
                          (r.centerx, r.centery + 38), C_GOLD, self.font_s, center=True)
                rects[f"level_{n}"] = r
            else:
                self.text("Закрыто", (r.centerx, r.centery + 20), C_DIM,
                          self.font_s, center=True)

        r = pygame.Rect(WIDTH // 2 - 130, y0 + 2 * (bh + gap) + 30, 260, 40)
        pygame.draw.rect(scr, (90, 60, 60), r, border_radius=8)
        self.text("Сбросить прогресс", r.center, C_TEXT, self.font_s, center=True)
        rects["reset"] = r


# ============================================================================
# МОДУЛЬ E (Участник 5): ТОЧКА ВХОДА — переключение меню/игра, главный цикл
# ============================================================================

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Tower Defense — летняя практика (расширенная версия)")
    clock = pygame.time.Clock()
    rend = Renderer(screen)

    save = load_save()
    scene = "menu"
    game = None
    menu_rects = {}

    running = True
    while running:
        dt = min(clock.tick(FPS) / 1000.0, 0.05)        # защита от скачка времени

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False

            elif scene == "menu":
                if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                    for key, r in menu_rects.items():
                        if r.collidepoint(ev.pos):
                            if key == "reset":
                                save = {"unlocked": 1, "best_lives": {}}
                                write_save(save)
                            elif key.startswith("level_"):
                                game = Game(int(key[6:]), save)
                                scene = "game"
                            break

            elif scene == "game":
                if ev.type == pygame.KEYDOWN:
                    if ev.key == pygame.K_ESCAPE:
                        if game.build_sel or game.tower_sel:
                            game.build_sel = None
                            game.tower_sel = None
                        else:
                            scene = "menu"
                    elif ev.key == pygame.K_SPACE:
                        game.paused = not game.paused
                    elif ev.key == pygame.K_r and game.state in ("win", "lose"):
                        game = Game(game.level["number"], save)
                elif ev.type == pygame.MOUSEBUTTONDOWN:
                    action = game.handle_click(ev.pos, ev.button)
                    if action == "btn_restart":
                        game = Game(game.level["number"], save)
                    elif action == "btn_menu":
                        scene = "menu"
                    elif action == "btn_next":
                        game = Game(game.level["number"] + 1, save)

        if scene == "game":
            game.update(dt)
            rend.draw_game(game)
        else:
            rend.draw_menu(save, menu_rects)

        pygame.display.flip()

    pygame.quit()
    sys.exit(0)


if __name__ == "__main__":
    main()
